<div class="right_col" role="main" style="height: 100%">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <br>
                <h3>Proposal Diterima</h3>
            </div>
            <div class="title_right">
                <br>
                <form class="form-horizontal form-label-left input_mask">
                    <div class="col-md-6 col-sm-6 col-xs-12 form-group">
                        <select class="form-control" name="periode">
                            <option>Periode</option>
                            <option>2016/2017</option>
                            <option>2017/2018</option>
                        </select>
                    </div>
                    <div class="col-md-6 col-sm-5 col-xs-12 form-group">
                        <input type="submit" value="kirim" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-12 col-sm-6 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Proposal</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table id="datatable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Judul</th>
                                <th>Biaya</th>
                                <th>Nama</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>loren ipsum</td>
                                <td>Rp.1.000.000</td>
                                <td>zaenur</td>
                                <td>
                                    <a href="#">Download</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
</div>