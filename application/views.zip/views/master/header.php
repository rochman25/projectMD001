<nav class="navbar navbar-expand bg-light static-top" style="margin-top:0px">
    <div class="container">
        <div class="row" style="margin:auto">
            <div class="col-lg-2" style="margin:0px">
                <a href="index.html">
                    <img src="<?= base_url(); ?>assets/img/amikom_logo.png" width="100px" height="100px">
                </a>
            </div>
            <div class="col-lg-10" style="margin-top:10px">
                <div class="text-center text-white" style="margin-left:50px"><h2>Aplikasi Penilaian Kinerja Karyawan</h2>
                    <h4>STMIK AMIKOM PURWOKERTO</h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Navbar Search -->
    <!-- Navbar -->
</nav>