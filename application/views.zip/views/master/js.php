<script src="<?=base_url();?>assets/vendors/jquery/dist/jquery.min.js"></script>
<script src="<?=base_url();?>assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?=base_url();?>assets/js/conditional.js"></script>
<!-- FastClick -->
<script src="<?=base_url();?>assets/vendors/fastclick/lib/fastclick.js"></script>
<script src="<?=base_url();?>assets/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url();?>assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?=base_url();?>assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="<?=base_url();?>assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="<?=base_url();?>assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?=base_url();?>assets/vendors/nprogress/nprogress.js"></script>
<!-- iCheck -->
<script src="<?=base_url();?>assets/vendors/iCheck/icheck.min.js"></script>
<!-- jQuery Tags Input -->
<script src="<?=base_url();?>assets/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
<!-- Chart.js -->
<script src="<?=base_url();?>assets/vendors/Chart.js/dist/Chart.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?=base_url();?>assets/js/custom.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#myModal").modal({backdrop: 'static', keyboard: false},'show');
        $('#ModalN').click(function(){
            $("#myModal").modal('hide');
  		    $('#ModalU').modal({backdrop: 'static', keyboard: false},'show');
        });
        $('#nidn1').change(function(){
            var nidn=$(this).val();
            $.ajax({
                url : "<?php echo base_url();?>user/get_dosen",
                method : "POST",
                data : {nidn: nidn},
                async : false,
                dataType : 'json',
                success: function(data){
                    var html = "testing";
                    //var i;
                    console.log(data);
                    //$('#nama1').val(html);
                }
            });
        });
        $('#tambah_anggota').on('click',function(){
            var nidn=$('#nidn1').val();
            var nim=$('#nim1').val();
            var nama=$('#namaAng').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo base_url('index.php/barang/simpan_barang')?>",
                dataType : "JSON",
                data : {kobar:kobar , nabar:nabar, harga:harga},
                success: function(data){
                    $('[name="kobar"]').val("");
                    $('[name="nabar"]').val("");
                    $('[name="harga"]').val("");
                    $('#ModalaAdd').modal('hide');
                    tampil_data_barang();
                }
            });
            return false;
        });
        
        //$("#myModal").modal({,backdrop: 'static', keyboard: false}) 
    });

</script>
