<div class="right_col" role="main" style="height: 100%">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Evaluasi Usulan Periode <?= $periode->nama ?></h3>
            </div>
        </div>
        <div class="col-md-12 col-sm-6 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Data Proposal</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">

                    <table id="datatable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Judul</th>
                                <th>Skema</th>
                                <th>Kelengkapan</th>
                                <th>Keterangan</th>
                                <th>Status</th>
                                <!-- <th>Keterangan</th> -->
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                                //foreach($proposal as $p){
                                    if($proposal != null){
                            ?>

                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?php echo $proposal->judul ?></td>
                                    <td><?php echo $proposal->jenis ?></td>
                                    <td><?php echo $proposal->kelengkapan?></td>
                                    <td><?php echo $proposal->keterangan?></td>
                                    <td><?php echo $proposal->status ?></td>
                                    <td><a href="#" class="btn btn-sm btn-success" data-toggle="modal" data-target="#modalEdit<?= $proposal->nidn ?>">
                                            <i class="fa fa-edit"></i> Edit</a>
                                        <a href="<?= base_url(); ?>admin/administrator/hapus/<?= $proposal->id ?>" class="btn btn-sm btn-danger">
                                            <i class="fa fa-trash"></i> Hapus</a>
                                    </td>
                                </tr>
                                <?php
                                }
                                ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>