<?php


class Peninjau extends CI_Controller{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('DataModel');
        $this->load->library('form_validation');
        if (!$this->checkSession()) {
            $data['login'] = "admin";
            $this->load->view('master/login', $data);
        }
    }

    public function checkSession()
    {
        $cek = $this->session->userdata("id");
        if (empty($cek)) {
            return false;
        } else {
            return true;
        }
    }

    public function index(){
        $data['page'] = 'admin/peninjau';
        $data['admin'] = $this->DataModel->getJoin('dosen','dosen.nidn = admin.nidn','inner');
        $data['admin'] = $this->DataModel->getWhere('admin.level','PE');
        $data['admin'] = $this->DataModel->getData('admin')->result_array();
        $data['dosen'] = $this->DataModel->select('dosen.nidn');
        $data['dosen'] = $this->DataModel->getJoin('admin','admin.nidn = dosen.nidn','inner');
        $data['dosen'] = $this->DataModel->getWhere('dosen.nidn','IS NULL');
        $data['dosen'] = $this->DataModel->getData('dosen')->result_array();
        $data['nidnDosen'] = $this->DataModel->select('nidn,nama');
        $data['nidnDosen'] = $this->DataModel->getWhere('nidn !=', $this->session->userdata('nidn'));
        $data['nidnDosen'] = $this->DataModel->getData('dosen')->result_array();

        $this->load->view('master/dashboard',$data);
    }

    public function tambah(){
        $nidn = $this->input->post('nidn');
        $data = array(
            "nidn" => $nidn,
            "password" => "peninjau",
            "level" => "PE",
        );
        $result = $this->DataModel->insert('admin',$data);
        if($result){
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissable">
                                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                    <p>Data Berhasil ditambahkan</p></div>');
            
        }else{
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissable">
                                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                    <p>Data Gagal ditambahkan</p></div>');
        }
        redirect('admin/peninjau');
    }

    public function edit(){

    }

    public function hapus(){

    }


}