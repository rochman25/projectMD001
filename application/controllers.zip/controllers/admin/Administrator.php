<?php


class Administrator extends CI_Controller{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('DataModel');
        $this->load->library('form_validation');
        if (!$this->checkSession()) {
            $data['login'] = "admin";
            $this->load->view('master/login', $data);
        }
    }

    public function checkSession()
    {
        $cek = $this->session->userdata("id");
        if (empty($cek)) {
            return false;
        } else {
            return true;
        }
    }

    public function index(){
            $data['page'] = 'admin/administrator';
            $data['admin'] = $this->DataModel->getJoin('dosen','dosen.nidn = admin.nidn','inner');
            $data['admin'] = $this->DataModel->getData('admin')->result_array();
            $data['dosen'] = $this->DataModel->select('dosen.nidn');
            $data['dosen'] = $this->DataModel->getJoin('admin','admin.nidn = dosen.nidn','inner');
            $data['dosen'] = $this->DataModel->getWhere('dosen.nidn','IS NULL');
            $data['dosen'] = $this->DataModel->getData('dosen')->result_array();
            $this->load->view('master/dashboard',$data);
    }

    public function tambah(){
        $nidn = $this->input->post('nidn');
        $level = $this->input->post('level');
        if($level == "0" || $nidn == "0"){
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissable">
                                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                        <p>NIDN atau Jabatan Belum dipilih</p></div>');
            $data['page'] = "admin/dosen";
            $this->load->view('master/dashboard', $data);
        }else{
            $data = array(
                "nidn" => $nidn,
                "password" => "admin",
                "level" => $level
            );
            $result = $this->DataModel->insert('admin',$data);
            if($result){
                $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissable">
                                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                        <p>Data Berhasil ditambahkan</p></div>');
            }else{
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissable">
                                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                        <p>Data Gagal ditambahkan</p></div>');
            }
            $data['page'] = 'admin/administrator';
            $data['admin'] = $this->DataModel->getJoin('dosen','dosen.nidn = admin.nidn','inner');
            $data['admin'] = $this->DataModel->getData('admin')->result_array();
            $data['dosen'] = $this->DataModel->select('dosen.nidn');
            $data['dosen'] = $this->DataModel->getJoin('admin','admin.nidn != dosen.nidn','inner');
            $data['dosen'] = $this->DataModel->getData('dosen')->result_array();
            $this->load->view('master/dashboard',$data);
        }
    }

    public function hapus($id){
            $result = $this->DataModel->getWhere('id',$id);
            $result = $this->DataModel->delete('admin');
            
            if($result){
                $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissable">
                                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                        <p>Data Berhasil dihapus</p></div>');                                            
            }else{
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissable">
                                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                        <p>Data Gagal dihapus</p></div>');
            }
            $data['page'] = 'admin/administrator';
            $data['admin'] = $this->DataModel->getJoin('dosen','dosen.nidn = admin.nidn','inner');
            $data['admin'] = $this->DataModel->getData('admin')->result_array();
            $data['dosen'] = $this->DataModel->select('dosen.nidn');
            $data['dosen'] = $this->DataModel->getJoin('admin','admin.nidn = dosen.nidn','full outer');
            $data['dosen'] = $this->DataModel->getData('dosen')->result_array();
            $this->load->view('master/dashboard',$data);
    }
}